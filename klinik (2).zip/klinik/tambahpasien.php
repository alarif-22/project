<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include "head.php" ?>
  </head>
  <body>
  <?php include "navbar.php" ?>

  <div class="container mt-3">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <h4>Form Pasien</h4>
                <a href="pasien.php" class="btn btn-warning">Kembali</a>
                <hr>

                <form method="post" action="" enctype="multipart/form-data">
                    <p>ID Pasien :
                        <input type="text" name="id_pasien" placeholder="id_pasien" class="form-control">
                    </p>
                    <p>Nama Pasien :
                        <input type="text" name="nama_pasien" placeholder="nama_pasien" class="form-control">
                    </p>
                    <p>Jenis Kelamin :
                        <input type="text" name="jenis_kelamin" placeholder="jenis_kelamin" class="form-control">
                    </p>
                    <p>Usia :
                        <input type="text" name="usia" placeholder="usia" class="form-control">
                    </p>
                    <input type="submit" value="Simpan" class="btn btn-primary">
                </form>


                <?php
                if (isset($_POST['id_pasien'])) {
                    include "koneksi.php";

                    $id_pengguna = $_POST['id_pasien'];
                    $nama_pasien = $_POST['nama_pasien'];
                    $jenis_kelamin = $_POST['jenis_kelamin'];
                    $usia = $_POST['usia'];
                
                    $sql = "INSERT INTO pasien VALUES('$id_pasien','$nama_pasien','$jenis_kelamin', '$usia')";
                    mysqli_query($koneksi, $sql);
                    header('location: pasien.php');
                    }
                   
                
                ?>

            </div>
        </div>
    </div>
    <?php include "footer.php" ?>

  </body>
</html>

<!DOCTYPE html>
<html lang="en">

<head>
<?php include "head.php" ?>
</head>
<body>
<?php include "navbar.php" ?>

  <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img
          src="https://assets.ayojakarta.com/crop/0x0:0x0/750x500/webp/photo/ayojakarta/images/post/articles/2019/11/21/8152/ilustrasi_klinik_2_(mediakonsumen.com.jpg"
          class="d-block w-100" alt="klinik">
      </div>
      <div class="carousel-item active">
        <img
          src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.istockphoto.com%2Fid%2Ffoto-foto%2Fklinik-ilustrasi&psig=AOvVaw2DOlQK0PN-wqAGmFxrdZjw&ust=1684197167794000&source=images&cd=vfe&ved=0CBEQjRxqFwoTCNjtocKJ9v4CFQAAAAAdAAAAABAR"
          class="d-block w-100" alt="klinik1">
      </div>
      <div class="carousel-item active">
        <img
          src="https://img.lovepik.com/photo/40195/1367_lovepik-clinic-doctor-reception-patient-vector-illustration-image_wh860.jpg"
          class="d-block w-100" alt="klinikk">
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row mt-3">
      <div class="col-6" style="background-color: rgb(255, 255, 255);">
        <img src="https://assets.digination.id/crop/0x0:0x0/x/photo/2019/05/10/78176345.jpg" class="rounded float-start"
          alt="klinik png" height="90%" width="50%">

      </div>
      <div class="col-6" style="background-color: rgb(255, 255, 255);">
        <h1 class="display-1"> KLINIK JAVANA</h1>

      </div>
      <hr />
      <div class="row">
        <div class="col-4" style="background: rgb(244, 244, 245);">
          <h4>Apa itu klinik javana?</h4>
        </div>
        <div class="col-8" style="background: rgb(244, 244, 245);">

          <p>klinik javana adalah sebuah layanan kesehatan berbasis web yang bertujuan memudahkan pengguna juga sebagai
            peningkatkan pelayanan klinik menjadi lebih baik lagi agar terus berkembang</p>
        </div>
        <hr>
        <div class="row">
          <div class="col-4" style="background: rgb(244, 244, 245);">
            <img src="me.png" alt="saya" height="80%" width="70%">

          </div>
          <div class="col-8" style="background: rgb(244, 244, 245);">
            <h4>Tentang saya</h4>
            <hr>
            <p>hai, perkenalkan. nama ku muhammad al arif mahasiswa smester 2 prodi sistem informasi di Universitas
              Islam Negeri Suthan Thaha Saifuddin Jambi. aku asli sumatraselatan tepat nya di desa wonorejo kecamatan
              bayung lencir kabupaten musi banyuasin provinsi sumatera selatan</p>
          </div>
        </div>
      </div>
    </div></div>

  <?php include "footer.php" ?>
</body>

</html>
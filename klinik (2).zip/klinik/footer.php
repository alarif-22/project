<hr />
  
  <div class="">
    <footer class="text-center text-white" style="background-color: #252525">
  
      <div class="container">
  
        <section class="mt-5">
  
          <div class="row text-center d-flex justify-content-center pt-5">
  
            <div class="col-md-2">
              <h6 class="text-uppercase font-weight-bold">
                <a href="#!" class="text-white">About us</a>
              </h6>
            </div>
  
  
  
            <div class="col-md-2">
              <h6 class="text-uppercase font-weight-bold">
                <a href="#!" class="text-white">Products</a>
              </h6>
            </div>
  
  
            <div class="col-md-2">
              <h6 class="text-uppercase font-weight-bold">
                <a href="#!" class="text-white">Awards</a>
              </h6>
            </div>
  
            <div class="col-md-2">
              <h6 class="text-uppercase font-weight-bold">
                <a href="#!" class="text-white">Help</a>
              </h6>
            </div>
  
            <div class="col-md-2">
              <h6 class="text-uppercase font-weight-bold">
                <a href="https://api.whatsapp.com/send/?phone=%2B085357756004&text&type=phone_number&app_absent=0"
                  class="text-white">Contact</a>
              </h6>
            </div>
            <div class="col-md-2">
              <h6 class="text-uppercase font-weight-bold">
                <a href="https://instagram.com/a_rifxyz?igshid=ZGUzMzM3NWJiOQ==" class="text-white">SOCIAL
                  MEDIA</a>
              </h6>
            </div>
          </div>
  
        </section>
  
  
        <hr class="my-5" />
  
  
        <section class="mb-5">
          <div class="row d-flex justify-content-center">
            <div class="col-lg-8">
              <p>
                Bantu kami mengembangkan fitur dan kenyamanan dengan mengirimkan kritik dan saran atau hubungi
                kami
                melalui contact
              </p>
            </div>
          </div>
        </section>
  
        <section class="text-center mb-4">
          <a href="https://web.facebook.com/?_rdc=1&_rdr" class="text-white me-4">
            <i class="fab fa-facebook-f"></i>
  
          </a>
          <a href="https://twitter.com/0Manusia2" class="text-white me-4">
            <i class="fab fa-twitter"></i>
          </a>
          <a href="" class="text-white me-4">
            <i class="fab fa-google"></i>
          </a>
          <a href="https://instagram.com/a_rifxyz?igshid=ZGUzMzM3NWJiOQ==" class="text-white me-4">
            <i class="fab fa-instagram"></i>
          </a>
          <a href="" class="text-white me-4">
            <i class="fab fa-linkedin"></i>
          </a>
          <a href="" class="text-white me-4">
            <i class="fab fa-github"></i>
          </a>
        </section>
  
      </div>
  
  
  
      <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
        © 2023 Copyright:
        <a class="text-white" href="https://Klinikjavana.com/">Klinikjavana.com</a>
      </div>
      <!-- Copyright -->
    </footer>
    <!-- Footer -->
  </div>
<?php
    include "koneksi.php";
    $id_pasien = $_GET['id_pasien'];
    $sql = "DELETE FROM data_pemeriksaan WHERE id_pasien= '$id_pasien'";
    $query = mysqli_query($koneksi, $sql);
    header('location:pemeriksaan.php');
<?php
    include "koneksi.php";
    $id_pengguna = $_GET['id_pengguna'];
    $sql = "DELETE FROM form_pengguna WHERE id_pengguna= '$id_pengguna'";
    $query = mysqli_query($koneksi, $sql);
    header('location:pengguna.php');
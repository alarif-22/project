<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include "head.php" ?>
  </head>
  <body>
  <?php include "navbar.php" ?>

  <div class="container mt-3">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <h4>Form pemeriksaan</h4>
                <a href="pemeriksaan.php" class="btn btn-warning">Kembali</a>
                <hr>

                <form method="post" action="" enctype="multipart/form-data">
                    <p>ID Pasien :
                        <input type="text" name="id_pasien" placeholder="id_pasien" class="form-control">
                    </p>
                    <p>Nama Pasien :
                        <input type="text" name="nama_pasien" placeholder="nama_pasien" class="form-control">
                    </p>
                    <p>Tanggal Periksa :
                        <input type="date" name="tangal_periksa" placeholder="tangal_periksa" class="form-control">
                    </p>
                    <p>Nama Pasien :
                        <input type="text" name="nama_pasien" placeholder="nama_pasien" class="form-control">
                    </p>
                    <p>Keluhan :
                        <input type="text" name="keluhan" placeholder="keluhan" class="form-control">
                    </p>
                    <p>Diagnosa :
                        <input type="text" name="diagnosa" placeholder="diagnosa" class="form-control">
                    </p>

                    <input type="submit" value="Simpan" class="btn btn-primary">
                </form>


                <?php
                if (isset($_POST['id_pasien'])) {
                    include "koneksi.php";

                    $id_pengguna = $_POST['id_pasien'];
                    $nama_pasien = $_POST['nama_pasien'];
                    $tangal_periksa = $_POST['tangal_periksa'];
                    $keluhan = $_POST['keluhan'];
                    $diagnosa = $_POST['diagnosa'];
                    $sql = "INSERT INTO data_pemeriksaan VALUES('$id_pasien','$nama_pasien','$tangal_periksa', '$keluhan', '$diagnosa')";
                    mysqli_query($koneksi, $sql);
                    header('location: pemeriksaan.php');
                    }
                   
                
                ?>

            </div>
        </div>
    </div>
    <?php include "footer.php" ?>

  </body>
</html>

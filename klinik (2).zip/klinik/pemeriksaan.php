<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <?php include "navbar.php" ?>

    <div class="container mt-3">
        <div class="row">
            <div class="col">
                <h4>pemeriksaan</h4>
                <a href="tambahpemeriksaan.php" class="btn btn-primary">Tambah Pemeriksaan</a>
                <hr>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Tanggal</th>
                            <th>Keluhan</th>
                            <th>Diagnosa</th>
                            <th>Ubah</th>
                            <th>Hapus</th>
                        </tr>
                    </thead>
</div>
                        <?php
                        include "koneksi.php";

                        $sql = "SELECT * FROM data_pemeriksaan";
                        $query = mysqli_query($koneksi, $sql);

                        while ($baris = mysqli_fetch_array($query)) {
                            ?>
                            <tr>
                                <td><?php echo $baris['id_pasien'] ?></td>
                                <td><?php echo $baris['nama_pasien'] ?></td>
                                <td><?php echo $baris['tangal_periksa'] ?></td>
                                <td><?php echo $baris['keluhan'] ?></td>
                                <td><?php echo $baris['diagnosa'] ?></td>

                                <td>
                                    <a href="ubahpemeriksaan.php?id_pasien=<?php echo $baris['id_pasien'] ?>" class="btn btn-success btn-sm">Ubah</a>
                                </td>
                                <td>
                                    <a href="hapuspemeriksaan.php?id_pasien=<?php echo $baris['id_pasien'] ?>" class="btn btn-danger btn-sm">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php include "footer.php" ?>

</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <?php include "navbar.php" ?>

    <div class="container mt-3">
        <div class="row">
            <div class="col">
                <h4>Pengguna</h4>
                <a href="penggunaform.php" class="btn btn-primary">Tambah Pengguna</a>
                <hr>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Ubah</th>
                            <th>Hapus</th>
                        </tr>
                    </thead>
</div>
                        <?php
                        include "koneksi.php";

                        $sql = "SELECT * FROM form_pengguna";
                        $query = mysqli_query($koneksi, $sql);

                        while ($baris = mysqli_fetch_array($query)) {
                            ?>
                            <tr>
                                <td><?php echo $baris['id_pengguna'] ?></td>
                                <td><?php echo $baris['nama_pengguna'] ?></td>
                                <td><?php echo $baris['username'] ?></td>

                                <td>
                                    <a href="ubahdata.php?id_pengguna=<?php echo $baris['id_pengguna'] ?>" class="btn btn-success btn-sm">Ubah</a>
                                </td>
                                <td>
                                    <a href="hapusdata.php?id_pengguna=<?php echo $baris['id_pengguna'] ?>" class="btn btn-danger btn-sm">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php include "footer.php" ?>

</body>

</html>
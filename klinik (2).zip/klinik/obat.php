<!DOCTYPE html>
<html lang="en">

<head>
<?php include "head.php" ?>
</head>

<body>
<?php include "navbar.php" ?>

  <div class="container mt-3">
    <div class="row">
      <div class="col-6">
        <h4>Obat-obatan</h4>
      </div>
    </div>
    <hr>
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-6 mt-5">
          <div class="card shadow">
            <div class="card">
              <div class="card-header">Obat Pereda Nyeri</div>
              <div class="card-body">

                <h5>Paracetamol
                </h5>

                <p>Obat penurun panas dan pereda nyeri</p>
                <p></p>
                <p>Harga : Rp. 15.000/Pcs</p>
                <a href="" class="btn btn-success btn-sm">Beli</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-12 col-md-6 mt-5">
          <div class="card shadow">
            <div class="card">
              <div class="card-header">Penambah nafsu makan</div>
              <div class="card-body">
                <h5>Curvit kaplet</h5>
                <p>Vitamin penambah nafsu makan</p>
                <p>Harga : Rp. 21.000/Pcs</p>

                <a href="" class="btn btn-success btn-sm">Beli</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-6 mt-5">
          <div class="card shadow">
            <div class="card">
              <div class="card-header">Obat pengencer darah</div>
              <div class="card-body">
                <h5>Aspirin</h5>
                <p>Obat pengencer darah untuk penderita penyakit jantung</p>
                <p>Harga : Rp. 25.000/Pcs</p>
                <a href="" class="btn btn-success btn-sm">Beli</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-12 col-md-6 mt-5">
          <div class="card shadow">
            <div class="card">
              <div class="card-header">Obat Hipotensi</div>
              <div class="card-body">
                <h5>Midodrine</h5>
                <P>Obat untuk gejala Hipotensi</P>
                <p>Harga : Rp. 28.000/Pcs</p>
                <a href="" class="btn btn-success btn-sm">Beli</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

    <hr />
    
    <?php include "footer.php" ?>

</body>

</html>
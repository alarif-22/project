<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <?php include "navbar.php" ?>

    <div class="container mt-3">
        <div class="row">
            <div class="col">
                <h4>Data Pasien</h4>
                <a href="tambahpasien.php" class="btn btn-primary">Tambah Pasien</a>
                <hr>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID Pasien</th>
                            <th>Nama Pasien</th>
                            <th>Jenis Kelamin</th>
                            <th>Usia</th>
                            <th>Ubah</th>
                            <th>Hapus</th>
                        </tr>
                    </thead>
</div>
                        <?php
                        include "koneksi.php";

                        $sql = "SELECT * FROM pasien";
                        $query = mysqli_query($koneksi, $sql);

                        while ($baris = mysqli_fetch_array($query)) {
                            ?>
                            <tr>
                                <td><?php echo $baris['id_pasien'] ?></td>
                                <td><?php echo $baris['nama_pasien'] ?></td>
                                <td><?php echo $baris['jenis_kelamin'] ?></td>
                                <td><?php echo $baris['usia'] ?></td>
                                <td>
                                    <a href="ubahpasien.php?id_pasien=<?php echo $baris['id_pasien'] ?>" class="btn btn-success btn-sm">Ubah</a>
                                </td>
                                <td>
                                    <a href="hapuspasien.php?id_pasien=<?php echo $baris['id_pasien'] ?>" class="btn btn-danger btn-sm">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php include "footer.php" ?>

</body>

</html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <?php include "navbar.php" ?>

    <?php
    include "koneksi.php";
    $id_pengguna = $_GET['id_pengguna'];
    $sql = "SELECT * FROM form_pengguna WHERE id_pengguna = '$id_pengguna'";
    $query = mysqli_query($koneksi, $sql);
    $data = mysqli_fetch_array($query);
    ?>

    <div class="container mt-3">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <h4>Form ubah pengguna</h4>
                <a href="pengguna.php" class="btn btn-warning">Kembali</a>
                <hr>

                <form method="post" action="" enctype="multipart/form-data">
                        <p>ID pengguna :
                        <input type="text" name="id_pengguna" value="<?php echo $data['id_pengguna']; ?>" placeholder="id_pengguna" class="form-control">
                    </p>
                    
                        <p>Nama Pengguna :
                        <input type="text" name="nama_pengguna" value="<?php echo $data['nama_pengguna']; ?>" placeholder="nama_pengguna" class="form-control">
                    <p>
                        <p>Username :
                        <input type="text" name="username" value="<?php echo $data['username']; ?>" placeholder="username" class="form-control">
                    <p>

                    <input type="submit" value="Simpan" class="btn btn-primary">
                </form>

            </div>
        </div>
    </div>
    
    <?php
                if (isset($_POST['id_pengguna'])) {
                    $id_pengguna = $_POST['id_pengguna'];
                    $nama_pengguna = $_POST['nama_pengguna'];
                    $username = $_POST['username'];

                    $sql = "UPDATE form_pengguna SET nama_pengguna = '$nama_pengguna', username = '$username' WHERE id_pengguna = '$id_pengguna'";
                    mysqli_query($koneksi, $sql);
                    header('location: pengguna.php');
                }
                ?>
    <?php include "footer.php" ?>

</body>

</html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <?php include "navbar.php" ?>

    <?php
    include "koneksi.php";
    $id_pasien = $_GET['id_pasien'];
    $sql = "SELECT * FROM pasien WHERE id_pasien = '$id_pasien'";
    $query = mysqli_query($koneksi, $sql);
    $data = mysqli_fetch_array($query);
    ?>

    <div class="container mt-3">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <h4>Form ubah pasien</h4>
                <a href="pasien.php" class="btn btn-warning">Kembali</a>
                <hr>

                <form method="post" action="" enctype="multipart/form-data">
                    <p>ID Pasien :
                        <input type="text" name="id_pasien" value="<?php echo $data['id_pasien']; ?>" placeholder="id_pasien" class="form-control">
                    </p>
                    <p>Nama pasien :
                        <input type="text" name="nama_pasien" value="<?php echo $data['nama_pasien']; ?>" placeholder="nama_pasien" class="form-control">
                    </p>
                    <p>Jenis Kelamin :
                        <input type="text" name="jenis_kelamin" value="<?php echo $data['jenis_kelamin']; ?>" placeholder="jenis_kelamin" class="form-control">
                    </p>
                    <p>Usia :
                        <input type="text" name="usia" value="<?php echo $data['usia']; ?>" placeholder="usia" class="form-control">
                    </p>
                   

                    <input type="submit" value="Simpan" class="btn btn-primary">
                </form>

            </div>
        </div>
    </div>
    
    <?php
                if (isset($_POST['id_pasien'])) {
                    $id_pasien = $_POST['id_pasien'];
                    $nama_pasien = $_POST['nama_pasien'];
                    $jenis_kelamin = $_POST['jenis_kelamin'];
                    $usia = $_POST['usia'];
                   


                    $sql = "UPDATE pasien SET nama_pasien = '$nama_pasien', jenis_kelamin = '$jenis_kelamin', usia = '$usia'  WHERE id_pasien = '$id_pasien'";
                    mysqli_query($koneksi, $sql);
                    header('location: pasien.php');
                }
                ?>

<hr>
<?php include "footer.php" ?>

</body>

</html>
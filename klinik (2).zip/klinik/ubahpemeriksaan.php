<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <?php include "navbar.php" ?>

    <?php
    include "koneksi.php";
    $id_pasien = $_GET['id_pasien'];
    $sql = "SELECT * FROM data_pemeriksaan WHERE id_pasien = '$id_pasien'";
    $query = mysqli_query($koneksi, $sql);
    $data = mysqli_fetch_array($query);
    ?>

    <div class="container mt-3">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <h4>Form ubah pasien</h4>
                <a href="pemeriksaan.php" class="btn btn-warning">Kembali</a>
                <hr>

                <form method="post" action="" enctype="multipart/form-data">
                    <p>ID Pasien :
                        <input type="text" name="id_pasien" value="<?php echo $data['id_pasien']; ?>" placeholder="id_pasien" class="form-control">
                    </p>
                    <p>Nama pasien :
                        <input type="text" name="nama_pasien" value="<?php echo $data['nama_pasien']; ?>" placeholder="nama_pasien" class="form-control">
                    </p>
                    <p>Tanggal Periksaan :
                        <input type="text" name="tangal_periksa" value="<?php echo $data['tangal_periksa']; ?>" placeholder="tangal_periksa" class="form-control">
                    </p>
                    <p>Keluhan :
                        <input type="text" name="keluhan" value="<?php echo $data['keluhan']; ?>" placeholder="keluhan" class="form-control">
                    </p>
                    <p>Diagnosa :
                        <input type="text" name="diagnosa" value="<?php echo $data['diagnosa']; ?>" placeholder="diagnosa" class="form-control">
                    </p>

                    <input type="submit" value="Simpan" class="btn btn-primary">
                </form>

            </div>
        </div>
    </div>
    
    <?php
                if (isset($_POST['id_pasien'])) {
                    $id_pasien = $_POST['id_pasien'];
                    $nama_pasien = $_POST['nama_pasien'];
                    $tangal_periksa = $_POST['tangal_periksa'];
                    $keluhan = $_POST['keluhan'];
                    $diagnosa = $_POST['diagnosa'];


                    $sql = "UPDATE data_pemeriksaan SET nama_pasien = '$nama_pasien', tangal_periksa = '$tangal_periksa', keluhan = '$keluhan', diagnosa = '$diagnosa'  WHERE id_pasien = '$id_pasien'";
                    mysqli_query($koneksi, $sql);
                    header('location: pemeriksaan.php');
                }
                ?>
<hr>
<?php include "footer.php" ?>
</body>

</html>
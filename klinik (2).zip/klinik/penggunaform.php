<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include "head.php" ?>
  </head>
  <body>
  <?php include "navbar.php" ?>

  <div class="container mt-3">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <h4>Form Mahasiswa</h4>
                <a href="pengguna.php" class="btn btn-warning">Kembali</a>
                <hr>

                <form method="post" action="" enctype="multipart/form-data">
                    <p>ID Pasien :
                        <input type="text" name="id_pengguna" placeholder="id pengguna" class="form-control">
                    </p>
                    <p>Nama Pasien :
                        <input type="text" name="nama_pengguna" placeholder="nama pasien" class="form-control">
                    </p>
                    <p>Username :
                        <input type="text" name="username" placeholder="Username" class="form-control">
                    </p>

                    <input type="submit" value="Simpan" class="btn btn-primary">
                </form>


                <?php
                if (isset($_POST['id_pengguna'])) {
                    include "koneksi.php";

                    $id_pengguna = $_POST['id_pengguna'];
                    $nama_pengguna = $_POST['nama_pengguna'];
                    $username = $_POST['username'];
                    $sql = "INSERT INTO form_pengguna VALUES('$id_pengguna','$nama_pengguna','$username')";
                    mysqli_query($koneksi, $sql);
                    header('location: pengguna.php');
                    }
                   
                
                ?>

            </div>
        </div>
    </div>
    <?php include "footer.php" ?>

  </body>
</html>
